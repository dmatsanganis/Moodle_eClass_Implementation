========
Evaluate
========
.. _teacher_evaluate:

----------
Statistics
----------

In the submenu “Statistics”, teachers can view their own statistics and see the community statistics.

.. image:: ../_images/statistics.png
	:align: center

-------
Ranking
-------

On the “Ranking” page teachers can see all students progress, not only Top 10 as the students have.
Each student is shown with its total points, how the points are contributed and the personal progress.

.. image:: ../_images/ranking.png
	:align: center
