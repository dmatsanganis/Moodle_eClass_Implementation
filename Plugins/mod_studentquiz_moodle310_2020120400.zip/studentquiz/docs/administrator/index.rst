Administrator Manual
====================

You are the Moodle administrator maintaining the moodle installation of your
institution. This guide explains the relevant procedures of installation 
and upgrades as well as the process of an uninstalling StudentQuiz.

.. toctree::
   :maxdepth: 2
   :caption: Contents:
   
   install
   upgrade
   configure
   uninstall
