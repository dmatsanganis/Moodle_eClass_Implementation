Configure
=========

You can setup the points used by the ranking table, but these are just site wide default values. The teacher can
always overwrite them during creation of a StudentQuiz or when editing a StudentQuiz.

For more information about the ranking table look at the :ref:`Teacher Manual about Evaluating <teacher_evaluate>`
and :ref:`Student Manual about Scores <student_score>`
